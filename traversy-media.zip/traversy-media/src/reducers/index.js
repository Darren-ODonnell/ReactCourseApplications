import { combineReducers } from 'redux';
import postReducer from './postReducer';

// when creating a store we must present all the reducers that will  interact with the store,
// this is achieved by comining all the reducers in then app into a single reducer using combineReducers()
// this objectf 'rootReducer' is then presented to when using createStore();

// const rootReducer = combineReducers(
//   {
//   posts: postReducer
//   }
// );

export default combineReducers(
  {
  posts: postReducer
  }
);

// export default rootReducer;


