import {  createStore,  applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './reducers';


// With a plain basic Redux store, you can only do simple synchronous updates by dispatching an
// action. Middleware extends the store's abilities, and lets you write async logic that interacts with the store.

// Thunks are the recommended middleware
// for basic Redux side effects logic, including complex synchronous logic that needs access 
// to the store, and simple async logic like AJAX requests.



// setup the store
const initialState = {};

// middleware is presented to the app as an array of middleware - even though we are only using one.
const middleware = [thunk];

// three dots ... implies read all elements in array/collection 
const store = createStore(rootReducer,
   initialState, 
   compose(
     applyMiddleware(...middleware),
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()));

export default store;
